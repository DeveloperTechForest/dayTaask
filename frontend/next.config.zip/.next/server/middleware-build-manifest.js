globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a10a807882858842.js",
    "static/chunks/fc3f3ffa091376b1.js",
    "static/chunks/a4eeb46e07741350.js",
    "static/chunks/c15ed14a5e6a2999.js",
    "static/chunks/90e24abbc49cafbc.js",
    "static/chunks/turbopack-f13e78e60a27b7d0.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];