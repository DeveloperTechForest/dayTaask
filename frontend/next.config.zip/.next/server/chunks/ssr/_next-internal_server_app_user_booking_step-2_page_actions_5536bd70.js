module.exports=[566,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_user_booking_step-2_page_actions_5536bd70.js.map