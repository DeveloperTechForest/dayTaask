module.exports=[57665,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app__not-found_page_actions_554ec2bf.js.map