module.exports=[95080,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_categories_page_actions_78c18208.js.map