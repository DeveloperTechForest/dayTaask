module.exports=[93383,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_user_payment-success_page_actions_63c174b4.js.map