module.exports=[42369,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_categories_%5BcategoryId%5D_page_actions_1138ece7.js.map