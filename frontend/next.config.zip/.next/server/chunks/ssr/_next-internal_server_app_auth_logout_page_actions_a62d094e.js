module.exports=[59021,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_logout_page_actions_a62d094e.js.map