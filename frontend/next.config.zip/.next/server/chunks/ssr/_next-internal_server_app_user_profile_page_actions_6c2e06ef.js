module.exports=[96138,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_user_profile_page_actions_6c2e06ef.js.map