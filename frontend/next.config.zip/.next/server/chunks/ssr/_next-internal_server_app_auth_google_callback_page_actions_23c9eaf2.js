module.exports=[63782,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_google_callback_page_actions_23c9eaf2.js.map