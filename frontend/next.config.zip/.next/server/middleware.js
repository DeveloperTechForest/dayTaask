var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[root-of-the-server]__f9e520a4._.js")
R.c("server/chunks/[root-of-the-server]__1fc116a8._.js")
R.m(15838)
module.exports=R.m(15838).exports
